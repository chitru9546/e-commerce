$(function(){
    $("#header-div").load("/common/header.html"); 
    $("#footer").load("/common/footer.html"); 
  });
  
  const header = document.getElementById("header-div");
    header.style.position = "sticky";
    header.style.top = "0px";
    header.style.zIndex = "100";
    
    
    
    
    
    


